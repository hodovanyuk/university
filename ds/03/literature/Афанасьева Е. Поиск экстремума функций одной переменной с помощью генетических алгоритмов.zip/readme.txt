
 Searching optimum. One-dimensional multi-modal search.
 Single variable function maximization. 


 Written by Elena Afanasyeva.
 Transport and Telecommunications Institute (TSI) 2001.
 Riga, Latvia.


 This program is free software and may be distributed according to the terms
 of the GNU Public License.

