
 Searching optimum. One-dimensional multi-modal search. Single variable
 function maximization (26 September 2001).


 Written by Alexey Popov (xela@tsi.lv).
 Transport and Telecommunications Institute (TSI) 2001.
 Riga, Latvia.


 This program is free software and may be distributed according to the terms
 of the GNU Public License.
